const perguntas = [

    {
        pergunta:
            "Qual é a maior floresta tropical do mundo?",

        respostas: [
            "Mata Atlântica",
            "Floresta Amazônica",
            "Floresta Negra",
            "Taiga"
        ],

        correta: 1
    },

    {
        pergunta:
            "Qual gás as plantas absorvem durante a fotossíntese?",

        respostas: [
            "Oxigênio",
            "Nitrogênio",
            "Gás carbônico (CO₂)",
            "Hidrogênio"
        ],

        correta: 2
    },

    {
        pergunta:
            "Qual é o maior animal do planeta?",

        respostas: [
            "Elefante-africano",
            "Tubarão-baleia",
            "Baleia-azul",
            "Orca"
        ],

        correta: 2
    },

    {
        pergunta:
            "Qual é o maior oceano da Terra?",

        respostas: [
            "Atlântico",
            "Índico",
            "Ártico",
            "Pacífico"
        ],

        correta: 3
    },

    {
        pergunta:
            "Qual bioma ocupa a maior parte do território brasileiro?",

        respostas: [
            "Cerrado",
            "Amazônia",
            "Caatinga",
            "Pantanal"
        ],

        correta: 1
    },

    {
        pergunta:
            "Qual destes animais é um mamífero?",

        respostas: [
            "Tartaruga",
            "Jacaré",
            "Baleia",
            "Pinguim"
        ],

        correta: 2
    },

    {
        pergunta:
            "Qual é a principal fonte de energia da Terra?",

        respostas: [
            "Lua",
            "Sol",
            "Vento",
            "Água"
        ],

        correta: 1
    },

    {
        pergunta:
            "Qual destes é um recurso natural renovável?",

        respostas: [
            "Petróleo",
            "Carvão",
            "Luz solar",
            "Gás natural"
        ],

        correta: 2
    },

    {
        pergunta:
            "Qual destes animais é um importante polinizador?",

        respostas: [
            "Cobra",
            "Abelha",
            "Tubarão",
            "Crocodilo"
        ],

        correta: 1
    },

    {
        pergunta:
            "Qual é o maior felino das Américas?",

        respostas: [
            "Onça-pintada",
            "Leão",
            "Tigre",
            "Guepardo"
        ],

        correta: 0
    },

    {
        pergunta:
            "Qual é o processo pelo qual as plantas produzem seu alimento?",

        respostas: [
            "Respiração",
            "Evaporação",
            "Fotossíntese",
            "Germinação"
        ],

        correta: 2
    },

    {
        pergunta:
            "Qual destes animais vive principalmente no Polo Sul?",

        respostas: [
            "Urso-polar",
            "Pinguim",
            "Foca-cinzenta",
            "Lobo-do-ártico"
        ],

        correta: 1
    },

    {
        pergunta:
            "Qual é o planeta conhecido como Planeta Azul?",

        respostas: [
            "Marte",
            "Terra",
            "Netuno",
            "Vênus"
        ],

        correta: 1
    },

    {
        pergunta:
            "Qual destes materiais demora mais para se decompor?",

        respostas: [
            "Papel",
            "Casca de banana",
            "Garrafa plástica",
            "Folha seca"
        ],

        correta: 2
    },

    {
        pergunta:
            "Qual é o maior deserto do mundo?",

        respostas: [
            "Saara",
            "Atacama",
            "Antártida",
            "Gobi"
        ],

        correta: 2
    },

    {
        pergunta:
            "Qual destes animais é um réptil?",

        respostas: [
            "Sapo",
            "Jacaré",
            "Morcego",
            "Golfinho"
        ],

        correta: 1
    },

    {
        pergunta:
            "Qual camada da Terra contém a maior parte do ar que respiramos?",

        respostas: [
            "Estratosfera",
            "Mesosfera",
            "Troposfera",
            "Exosfera"
        ],

        correta: 2
    },

    {
        pergunta:
            "Qual é o rio mais extenso do Brasil?",

        respostas: [
            "Paraná",
            "São Francisco",
            "Amazonas",
            "Tocantins"
        ],

        correta: 2
    },

    {
        pergunta:
            "Qual destes é um exemplo de energia limpa?",

        respostas: [
            "Carvão",
            "Petróleo",
            "Energia eólica",
            "Diesel"
        ],

        correta: 2
    },

    {
        pergunta:
            "Qual destes animais está ameaçado de extinção no Brasil?",

        respostas: [
            "Onça-pintada",
            "Pombo",
            "Galinha",
            "Rato"
        ],

        correta: 0
    },

    {
        pergunta:
            "Qual é a função principal das árvores?",

        respostas: [
            "Produzir plástico",
            "Absorver CO₂ e liberar oxigênio",
            "Produzir petróleo",
            "Aumentar a poluição"
        ],

        correta: 1
    },

    {
        pergunta:
            "Qual bioma é conhecido pelas áreas alagadas?",

        respostas: [
            "Cerrado",
            "Pantanal",
            "Caatinga",
            "Pampa"
        ],

        correta: 1
    },

    {
        pergunta:
            "Qual destes animais vive na Amazônia?",

        respostas: [
            "Onça-pintada",
            "Canguru",
            "Panda",
            "Camelo"
        ],

        correta: 0
    },

    {
        pergunta:
            "Qual destes não é um gás do efeito estufa?",

        respostas: [
            "CO₂",
            "Metano",
            "Vapor d'água",
            "Oxigênio"
        ],

        correta: 3
    },

    {
        pergunta:
            "Qual destes animais é um anfíbio?",

        respostas: [
            "Sapo",
            "Lagarto",
            "Cobra",
            "Tartaruga"
        ],

        correta: 0
    },

    {
        pergunta:
            "Qual é a maior ave do mundo?",

        respostas: [
            "Harpia",
            "Avestruz",
            "Águia",
            "Condor"
        ],

        correta: 1
    },

    {
        pergunta:
            "Qual destes é um exemplo de reciclagem?",

        respostas: [
            "Jogar lixo no rio",
            "Reutilizar garrafas PET",
            "Queimar lixo",
            "Enterrar plástico"
        ],

        correta: 1
    },

    {
        pergunta:
            "Principal gás emitido pelas atividades humanas?",

        respostas: [
            "Oxigênio",
            "Nitrogênio",
            "CO₂",
            "Hélio"
        ],

        correta: 2
    },

    {
        pergunta:
            "Qual é o maior peixe do mundo?",

        respostas: [
            "Tubarão-branco",
            "Baleia-azul",
            "Tubarão-baleia",
            "Atum"
        ],

        correta: 2
    },

    {
        pergunta:
            "Principal função da camada de ozônio?",

        respostas: [
            "Produzir chuva",
            "Refletir luz da Lua",
            "Filtrar radiação UV",
            "Produzir oxigênio"
        ],

        correta: 2
    }

];




const startScreen =
    document.getElementById(
        "start-screen"
    );


const startBtn =
    document.getElementById(
        "start-btn"
    );


const playerNameInput =
    document.getElementById(
        "player-name"
    );


const nameError =
    document.getElementById(
        "name-error"
    );


const quizContainer =
    document.querySelector(
        ".quiz-container"
    );


const playerDisplay =
    document.getElementById(
        "player-display"
    );


const questionElement =
    document.getElementById(
        "question"
    );


const answersElement =
    document.getElementById(
        "answers"
    );


const currentQuestionElement =
    document.getElementById(
        "current-question"
    );


const totalQuestionsElement =
    document.getElementById(
        "total-questions"
    );


const nextBtn =
    document.getElementById(
        "next-btn"
    );


const resultScreen =
    document.getElementById(
        "result-screen"
    );


const resultPlayer =
    document.getElementById(
        "result-player"
    );


const scoreElement =
    document.getElementById(
        "score"
    );


const maxScoreElement =
    document.getElementById(
        "max-score"
    );


const restartBtn =
    document.getElementById(
        "restart-btn"
    );




const rankingBtn =
    document.getElementById(
        "ranking-btn"
    );


const resultRankingBtn =
    document.getElementById(
        "result-ranking-btn"
    );


const rankingModal =
    document.getElementById(
        "ranking-modal"
    );


const closeRanking =
    document.getElementById(
        "close-ranking"
    );


const rankingList =
    document.getElementById(
        "ranking-list"
    );


const clearRankingBtn =
    document.getElementById(
        "clear-ranking"
    );




let perguntaAtual = 0;

let pontuacao = 0;

let respondeu = false;

let nomeJogador = "";




totalQuestionsElement.textContent =
    perguntas.length;


maxScoreElement.textContent =
    perguntas.length;




startBtn.addEventListener(
    "click",
    iniciarQuiz
);



playerNameInput.addEventListener(
    "keydown",
    function (event) {

        if (event.key === "Enter") {

            iniciarQuiz();

        }

    }
);



function iniciarQuiz() {

    const nome =
        playerNameInput.value.trim();




    if (nome === "") {

        nameError.textContent =
            "Digite seu nome para começar.";

        playerNameInput.focus();

        return;

    }


    nameError.textContent = "";


    nomeJogador = nome;


    perguntaAtual = 0;

    pontuacao = 0;

    respondeu = false;


    playerDisplay.textContent =
        "Jogador: " + nomeJogador;


    startScreen.classList.add(
        "hidden"
    );


    resultScreen.classList.add(
        "hidden"
    );


    quizContainer.classList.remove(
        "hidden"
    );


    mostrarPergunta();

}




function mostrarPergunta() {

    respondeu = false;


    nextBtn.style.display =
        "none";


    answersElement.innerHTML =
        "";


    const pergunta =
        perguntas[perguntaAtual];


    currentQuestionElement.textContent =
        perguntaAtual + 1;


    questionElement.textContent =
        pergunta.pergunta;




    pergunta.respostas.forEach(
        function (resposta, index) {

            const button =
                document.createElement(
                    "button"
                );


            button.textContent =
                resposta;


            button.classList.add(
                "answer-btn"
            );


            button.addEventListener(
                "click",
                function () {

                    selecionarResposta(
                        button,
                        index
                    );

                }
            );


            answersElement.appendChild(
                button
            );

        }
    );

}




function selecionarResposta(
    botaoSelecionado,
    indexSelecionado
) {



    if (respondeu) {

        return;

    }


    respondeu = true;


    const pergunta =
        perguntas[perguntaAtual];


    const botoes =
        document.querySelectorAll(
            ".answer-btn"
        );



    if (
        indexSelecionado ===
        pergunta.correta
    ) {

        botaoSelecionado
            .classList
            .add(
                "correct"
            );


        pontuacao++;

    }



    else {

        botaoSelecionado
            .classList
            .add(
                "wrong"
            );



        botoes[
            pergunta.correta
        ]
            .classList
            .add(
                "correct"
            );

    }





    botoes.forEach(
        function (botao) {

            botao.disabled =
                true;

        }
    );




    nextBtn.style.display =
        "block";





    if (
        perguntaAtual ===
        perguntas.length - 1
    ) {

        nextBtn.textContent =
            "Ver resultado";

    }

    else {

        nextBtn.textContent =
            "Próxima";

    }

}




nextBtn.addEventListener(
    "click",
    function () {

        perguntaAtual++;


        if (
            perguntaAtual <
            perguntas.length
        ) {

            mostrarPergunta();

        }

        else {

            mostrarResultado();

        }

    }
);




function mostrarResultado() {

    quizContainer.classList.add(
        "hidden"
    );


    resultScreen.classList.remove(
        "hidden"
    );


    resultPlayer.textContent =
        nomeJogador;


    scoreElement.textContent =
        pontuacao;


    salvarPontuacao();

}




function salvarPontuacao() {


    let ranking =
        JSON.parse(
            localStorage.getItem(
                "rankingQuizNatureza"
            )
        ) || [];





    const novoResultado = {

        nome:
            nomeJogador,

        pontos:
            pontuacao,

        total:
            perguntas.length,

        data:
            new Date()
                .toLocaleString(
                    "pt-BR"
                )

    };





    ranking.push(
        novoResultado
    );




    ranking.sort(
        function (a, b) {

            return (
                b.pontos -
                a.pontos
            );

        }
    );




    localStorage.setItem(

        "rankingQuizNatureza",

        JSON.stringify(
            ranking
        )

    );

}




function mostrarRanking() {

    const ranking =
        JSON.parse(
            localStorage.getItem(
                "rankingQuizNatureza"
            )
        ) || [];


    rankingList.innerHTML =
        "";





    if (ranking.length === 0) {

        rankingList.innerHTML = `

            <p class="empty-ranking">

                Nenhum jogador
                no ranking ainda.

            </p>

        `;

    }




    else {

        ranking.forEach(

            function (
                jogador,
                index
            ) {

                const item =
                    document.createElement(
                        "div"
                    );


                item.classList.add(
                    "ranking-item"
                );



                const posicao =
                    index + 1;



                let medalha =
                    "";



                if (
                    posicao === 1
                ) {

                    medalha =
                        "🥇";

                }


                else if (
                    posicao === 2
                ) {

                    medalha =
                        "🥈";

                }


                else if (
                    posicao === 3
                ) {

                    medalha =
                        "🥉";

                }



                item.innerHTML = `

                    <span>

                        ${medalha}

                        ${posicao}º

                    </span>


                    <span>

                        ${jogador.nome}

                    </span>


                    <strong>

                        ${jogador.pontos}
                        /
                        ${jogador.total}

                    </strong>

                `;



                rankingList.appendChild(
                    item
                );

            }

        );

    }



    rankingModal.classList.remove(
        "hidden"
    );

}




rankingBtn.addEventListener(
    "click",
    mostrarRanking
);


resultRankingBtn.addEventListener(
    "click",
    mostrarRanking
);




closeRanking.addEventListener(
    "click",
    function () {

        rankingModal.classList.add(
            "hidden"
        );

    }
);




rankingModal.addEventListener(
    "click",
    function (event) {

        if (
            event.target ===
            rankingModal
        ) {

            rankingModal
                .classList
                .add(
                    "hidden"
                );

        }

    }
);




document.addEventListener(
    "keydown",
    function (event) {

        if (
            event.key === "Escape"
        ) {

            rankingModal
                .classList
                .add(
                    "hidden"
                );

        }

    }
);




clearRankingBtn.addEventListener(
    "click",
    function () {

        const confirmar =
            confirm(
                "Tem certeza que deseja apagar todo o ranking?"
            );


        if (!confirmar) {

            return;

        }


        localStorage.removeItem(
            "rankingQuizNatureza"
        );


        mostrarRanking();

    }
);




restartBtn.addEventListener(
    "click",
    function () {

        perguntaAtual = 0;

        pontuacao = 0;

        respondeu = false;

        nomeJogador = "";


        playerNameInput.value =
            "";


        nameError.textContent =
            "";


        nextBtn.textContent =
            "Próxima";


        resultScreen.classList.add(
            "hidden"
        );


        quizContainer.classList.add(
            "hidden"
        );


        startScreen.classList.remove(
            "hidden"
        );


        playerNameInput.focus();

    }
);